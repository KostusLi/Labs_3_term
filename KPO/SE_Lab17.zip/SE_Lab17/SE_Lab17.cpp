﻿#include "stdafx.h"
#include <iostream>
#include <locale>
#include <cwchar>
#include <iomanip>
#include <sstream>
#include <string>

#include "Error.h"
#include "Parm.h"
#include "Log.h"
#include "In.h"
#include "Out.h"
#include "LT.h"
#include "IT.h"

using namespace std;


void Analyze(In::IN in, LT::LexTable& lt, IT::IdTable& it) {
    istringstream iss((char*)in.text);
    string token;
    int line = 1;

    while (iss >> token) {
        // если встретился перевод строки
        if (token.find('\n') != string::npos) {
            line++;
        }

        // примерная классификация
        LT::Entry lex;
        lex.sn = line;
        lex.idxTI = LT_TI_NULLIDX;

        if (token == "f") {
            lex.lexema[0] = LEX_FUNCTION;
        }
        else if (token == "d") {
            lex.lexema[0] = LEX_DECLARE;
        }
        else if (token == "r") {
            lex.lexema[0] = LEX_RETURN;
        }
        else if (isalpha(token[0])) {
            lex.lexema[0] = LEX_ID;

            // заносим в таблицу идентификаторов
            IT::Entry idEntry;
            strcpy_s(idEntry.id, sizeof(idEntry.id), token.c_str());
            idEntry.iddatatype = IT::INT;
            idEntry.idtype = IT::V;
            idEntry.idxfirstLE = lt.size;

            try {
                IT::Add(it, idEntry);
                lex.idxTI = it.size - 1;
            }
            catch (...) {
                ERROR_THROW(ERROR_IDTABLE_OVERFLOW);
            }
        }
        else {
            lex.lexema[0] = token[0]; // просто символ
        }

        try {
            LT::Add(lt, lex);
        }
        catch (...) {
            ERROR_THROW(ERROR_LEXTABLE_OVERFLOW);
        }
    }
}

int _tmain(int argc, _TCHAR* argv[])
{
    setlocale(LC_ALL, "russian");


    cout << "--------- тест geterror ---------\n\n";
    try { throw ERROR_THROW(100); }
    catch (Error::ERROR e)

    {
        cout << "Ошибка " << e.id << ": " << e.message << "\n\n";
    };


    cout << "--------- тест geterrorin ---------\n\n";
    try { throw ERROR_THROW_IN(111, 7, 7); }
    catch (Error::ERROR e)
    {
        cout << "Ошибка " << e.id << ": " << e.message << ", строка " << e.inext.line << ", позиция " << e.inext.col << " \n\n";
    };


    cout << "--------- тест getparm ---------\n\n";
    try {
        Parm::PARM parm = Parm::getparm(argc, argv);
        wcout << "-in:" << parm.in << ", -out:" << parm.out << ", -log:" << parm.log << "\n\n";
    }
    catch (Error::ERROR e)
    {
        cout << "Ошибка " << e.id << ": " << e.message << "\n\n";
    }

    cout << "--------- getin ----------\n\n";
    try
    {
        Parm::PARM parm = Parm::getparm(argc, argv);
        In::IN in = In::getin(parm.in);
        cout << in.text << endl;
        cout << "Всего символов: " << in.size << endl;
        cout << "Всего строк: " << in.lines << endl;
        cout << "Пропущено: " << in.ignor << endl;
    }
    catch (Error::ERROR e)
    {
        cout << "Ошибка " << e.id << ": " << e.message << endl;
        cout << "Строка " << e.inext.line << " позиция " << e.inext.col << "\n\n";
    }

    Log::LOG log = Log::INITLOG;

    try
    {
        Parm::PARM parm = Parm::getparm(argc, argv);
        log = Log::getlog(parm.log);
        Log::WriteLine(log, (char*)"Тест", (char*)" без ошибок \n", "");
        Log::WriteLine(log, (wchar_t*)L"Тест", (wchar_t*)L" без ошибок \n", L"");
        Log::WriteLog(log);
        Log::WriteParm(log, parm);
        In::IN in = In::getin(parm.in);
        Log::WriteIn(log, in);
        Log::Close(log);
    }
    catch (Error::ERROR e)
    {
        Log::WriteError(log, e);
    };

    Out::OUT out = Out::INITOUT;

    try {
        Parm::PARM parm = Parm::getparm(argc, argv);
        out = Out::getout(parm.out);
        In::IN in = In::getin(parm.in);
        Out::WriteInOut(out, in);
    }
    catch (Error::ERROR e)
    {
        Out::WriteErrorOut(out, e);
    };


    ofstream fout("protocol.txt");   // выходной файл

    try {
        // имитация входных данных (обычно вызываем In::getin(L"input.txt"))
        In::IN in{};
        const char* program = "tfi(ti,ti)\n{\ndti;\ni=iv(ivi);\nri;\n};";
        in.text = (unsigned char*)program;
        in.size = strlen(program);

        // создаем таблицы
        LT::LexTable lexTable = LT::Create(LT_MAXSIZE);
        IT::IdTable idTable = IT::Create(TI_MAXSIZE);

        // анализ
        Analyze(in, lexTable, idTable);

        // вывод таблицы лексем
        cout << "ТАБЛИЦА ЛЕКСЕМ:\n";
        for (int i = 0; i < lexTable.size; i++) {
            LT::Entry e = LT::GetEntry(lexTable, i);
            cout << e.sn << " " << e.lexema[0];
            if (e.idxTI != LT_TI_NULLIDX)
                cout << "(TI=" << e.idxTI << ")";
            cout << "\n";
        }

        // вывод таблицы идентификаторов
        cout << "\nТАБЛИЦА ИДЕНТИФИКАТОРОВ:\n";
        for (int i = 0; i < idTable.size; i++) {
            IT::Entry e = idTable.table[i];
            cout << i << ") " << e.id << " type=" << (e.iddatatype == IT::INT ? "int" : "string")
                << " firstLE=" << e.idxfirstLE << "\n";
        }

        // очистка
        LT::Delete(lexTable);
        IT::Delete(idTable);
    }
    catch (std::exception& ex) {
        cerr << "Ошибка: " << ex.what() << endl;
    }

    fout.close();


    cout << "-------------------------------------------------------------------------" << endl;
    system("pause");

    return 0;
}